package org.example.tugasmodulke6.util;

public interface iMenu {
    void menu();
}
