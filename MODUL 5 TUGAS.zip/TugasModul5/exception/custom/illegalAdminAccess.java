package modul5.tugas.exception.custom;

public class illegalAdminAccess extends Exception {
    public illegalAdminAccess(String message) {
        super(message);
    }
}
