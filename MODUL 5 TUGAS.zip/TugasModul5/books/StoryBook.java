package modul5.tugas.books;

public class StoryBook extends Book{
    public StoryBook(String idBuku, String judul, int stok, String category, String author) {
        super(idBuku, judul, stok, category, author);
    }
}
